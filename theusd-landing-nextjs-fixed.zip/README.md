# TheUSD Landing (Next.js + Tailwind)

Configured for **static export** and **GitHub Pages**.

## Dev
```bash
npm install
npm run dev
```

## Build (exports to out/)
```bash
npm run build
```

## Deploy
Push to `main`. GitHub Actions deploys `out/` to the `gh-pages` branch.
